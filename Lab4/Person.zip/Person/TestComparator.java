import java.util.*;
public class TestComparator {
	public static void main(String[] args) { 
		NameComparator nameComp = new NameComparator();
		AgeComparator ageComp = new AgeComparator();
		Person[] p = new Person[6];
		p[0] = new Person("Bill Gate", 15);
		p[1] = new Person("Apple", 20);
		p[2] = new Person("Ronaldo", 12);
		p[3] = new Person("Messi", 15);
		p[4] = new Person("Kaka", 12);
		p[5] = new Person("Andrew",19);
		List<Person> list1 = Arrays.asList(p);
		System.out.println(list1 + "\n");
		
		System.out.println("Sorting by age:");
		Collections.sort(list1, ageComp);
		System.out.println(list1 + "\n");

		List<Person> list2 = Arrays.asList(p);
		System.out.println("Sorting by name:");
		Collections.sort(list2, nameComp);
		System.out.println(list2 + "\n");

		System.out.println("Now sort by age, then sort by name:");
		Collections.sort(list2, ageComp); // list2 is already sorted by name
		System.out.println(list2);
	}
}

